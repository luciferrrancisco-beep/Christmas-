export enum TreeState {
  FORMED = 'FORMED', // The tree is solid and luxurious
  CHAOS = 'CHAOS',   // The tree is exploded (unleashed)
}

export interface DualPosition {
  target: [number, number, number]; // Position in the cone (Tree)
  chaos: [number, number, number];  // Position in the sphere (Explosion)
  scale: number;
  color: string;
  type: 'ornament' | 'gift' | 'light' | 'cat' | 'tomato' | 'icecream';
}

export interface SceneState {
  mode: TreeState;
  interactionValue: number; // 0 to 1 (0 = formed, 1 = chaos)
  setMode: (mode: TreeState) => void;
  setInteractionValue: (val: number) => void;
}
