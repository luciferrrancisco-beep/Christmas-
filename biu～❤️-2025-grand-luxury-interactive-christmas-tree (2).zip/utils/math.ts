import * as THREE from 'three';

// Helper to generate random point in a sphere
export const getRandomSpherePoint = (radius: number): [number, number, number] => {
  const u = Math.random();
  const v = Math.random();
  const theta = 2 * Math.PI * u;
  const phi = Math.acos(2 * v - 1);
  const r = Math.cbrt(Math.random()) * radius;
  const sinPhi = Math.sin(phi);
  return [
    r * sinPhi * Math.cos(theta),
    r * sinPhi * Math.sin(theta),
    r * Math.cos(phi)
  ];
};

// Helper to generate point in a cone (Tree shape)
export const getTreeConePoint = (
  height: number,
  baseRadius: number,
  yOffset: number = 0
): [number, number, number] => {
  const y = Math.random() * height; // Height from bottom
  const r = (1 - y / height) * baseRadius; // Radius at this height
  const angle = Math.random() * Math.PI * 2;
  
  // Add some irregularity
  const rJitter = r * (0.8 + Math.random() * 0.4);
  
  const x = rJitter * Math.cos(angle);
  const z = rJitter * Math.sin(angle);
  
  return [x, y + yOffset, z];
};

export const palette = {
  emerald: new THREE.Color('#022D16'),
  gold: new THREE.Color('#FFD700'),
  silver: new THREE.Color('#C0C0C0'),
  red: new THREE.Color('#8B0000'),
  glow: new THREE.Color('#FFFACD'),
};
