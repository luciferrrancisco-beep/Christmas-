import React, { useState, Suspense } from 'react';
import { Canvas } from '@react-three/fiber';
import Scene from './components/Scene';
import GestureControl from './components/GestureControl';
import { Loader } from '@react-three/drei';

const App: React.FC = () => {
  const [interactionLevel, setInteractionLevel] = useState(0);

  return (
    <div className="relative w-full h-full bg-black overflow-hidden font-sans">
      {/* UI Overlay */}
      <div className="absolute top-0 left-0 w-full p-6 flex justify-between items-start pointer-events-none z-10">
        <div>
          <h1 className="text-4xl md:text-6xl font-serif font-bold text-transparent bg-clip-text bg-gradient-to-r from-yellow-300 via-yellow-100 to-yellow-500 drop-shadow-[0_2px_10px_rgba(255,215,0,0.5)]">
            Biu～❤️
          </h1>
          <h2 className="text-lg text-emerald-400 font-light tracking-[0.2em] mt-2 uppercase">
            2025 Grand Luxury Tree
          </h2>
        </div>
        
        <div className="text-right hidden md:block">
           <div className="text-yellow-500/80 text-sm font-mono border border-yellow-500/30 px-3 py-1 rounded-full bg-black/50 backdrop-blur-md">
             LOCATION: LUNAR SURFACE
           </div>
           <div className="text-emerald-500/80 text-sm font-mono border border-emerald-500/30 px-3 py-1 rounded-full bg-black/50 backdrop-blur-md mt-2">
             STATUS: {interactionLevel > 0.3 ? "CHAOTIC" : "FORMED"}
           </div>
        </div>
      </div>

      {/* 3D Scene */}
      <div className="w-full h-full cursor-move">
        <Canvas
            shadows
            dpr={[1, 2]}
            gl={{ antialias: false, toneMappingExposure: 1.5 }}
        >
            <Suspense fallback={null}>
                <Scene interactionLevel={interactionLevel} />
            </Suspense>
        </Canvas>
        <Loader 
            containerStyles={{ background: 'black' }} 
            innerStyles={{ background: '#333', width: '200px' }}
            barStyles={{ background: '#FFD700', height: '5px' }}
            dataStyles={{ color: '#FFD700', fontFamily: 'serif' }}
        />
      </div>

      {/* Controls */}
      <GestureControl onUpdate={setInteractionLevel} />
      
      {/* Footer / Credits */}
      <div className="absolute bottom-4 right-4 text-white/20 text-xs font-mono pointer-events-none">
        React 19 • R3F • Postprocessing • Luxury Edition
      </div>
    </div>
  );
};

export default App;
