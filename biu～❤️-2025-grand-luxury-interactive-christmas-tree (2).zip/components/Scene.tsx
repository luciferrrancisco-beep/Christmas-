import React, { useRef, useState, useEffect } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { Environment, OrbitControls, ContactShadows, Stars } from '@react-three/drei';
import { EffectComposer, Bloom, Vignette } from '@react-three/postprocessing';
import * as THREE from 'three';

import Foliage from './Tree/Foliage';
import Ornaments from './Tree/Ornaments';
import DancingCats from './Environment/DancingCats';

interface SceneProps {
  interactionLevel: number;
}

const MoonFloor = () => {
  return (
    <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0, 0]} receiveShadow>
      <planeGeometry args={[100, 100, 64, 64]} />
      <meshStandardMaterial 
        color="#888888" 
        roughness={0.9} 
        metalness={0.2}
        displacementScale={2}
      >
      </meshStandardMaterial>
    </mesh>
  );
};

const CameraController = ({ interactionLevel }: { interactionLevel: number }) => {
    // Dynamic camera movement based on chaos
    useFrame((state) => {
        const t = state.clock.getElapsedTime();
        // Subtle sway
        const sway = Math.sin(t * 0.5) * 2;
        
        // When chaos increases, camera pulls back slightly and shakes
        const shake = interactionLevel * 0.1 * Math.sin(t * 20);
        
        const targetPos = new THREE.Vector3(
            sway, 
            4 + interactionLevel * 5, 
            20 + interactionLevel * 5 + shake
        );
        
        state.camera.position.lerp(targetPos, 0.05);
        state.camera.lookAt(0, 5, 0);
    });
    return null;
}

const Scene: React.FC<SceneProps> = ({ interactionLevel }) => {
  // Smooth out interaction level for visuals
  const [smoothProgress, setSmoothProgress] = useState(0);

  useFrame((_, delta) => {
    // Lerp smoothProgress towards interactionLevel
    const diff = interactionLevel - smoothProgress;
    setSmoothProgress(p => p + diff * delta * 2.0);
  });

  return (
    <>
      <CameraController interactionLevel={smoothProgress} />
      
      {/* Lighting */}
      <ambientLight intensity={0.2} />
      <Environment preset="lobby" />
      <directionalLight 
        position={[-5, 10, 5]} 
        intensity={2} 
        castShadow 
        color="#FFFACD"
      />

      {/* Post Processing */}
      <EffectComposer disableNormalPass>
        <Bloom 
            luminanceThreshold={0.8} 
            mipmapBlur 
            intensity={1.5} 
            radius={0.6}
        />
        <Vignette eskil={false} offset={0.1} darkness={0.5} />
      </EffectComposer>

      {/* Environment */}
      <Stars radius={100} depth={50} count={5000} factor={4} saturation={0} fade speed={1} />
      <MoonFloor />
      <DancingCats />

      {/* The Luxury Tree */}
      <group position={[0, 0, 0]}>
         {/* Trunk */}
         <mesh position={[0, 1, 0]}>
            <cylinderGeometry args={[0.8, 1.2, 3]} />
            <meshStandardMaterial color="#3E2723" roughness={1} />
         </mesh>
         
         {/* Dynamic Elements */}
         <Foliage progress={smoothProgress} />
         <Ornaments progress={smoothProgress} />
      </group>
      
      {/* Ground Shadows */}
      <ContactShadows opacity={0.5} scale={50} blur={2} far={10} resolution={256} color="#000000" />
    </>
  );
};

export default Scene;
