import React, { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';

const Cat = ({ position, offset }: { position: [number, number, number], offset: number }) => {
  const groupRef = useRef<THREE.Group>(null);

  useFrame((state) => {
    if (groupRef.current) {
      // Dance animation: Bob and rotate
      const t = state.clock.getElapsedTime() + offset;
      groupRef.current.position.y = position[1] + Math.abs(Math.sin(t * 5)) * 0.5;
      groupRef.current.rotation.z = Math.sin(t * 10) * 0.1;
      groupRef.current.rotation.y += 0.01;
    }
  });

  return (
    <group ref={groupRef} position={new THREE.Vector3(...position)}>
       {/* Body */}
       <mesh position={[0, 0.5, 0]}>
         <coneGeometry args={[0.3, 1, 8]} />
         <meshStandardMaterial color="orange" roughness={0.8} />
       </mesh>
       {/* Head */}
       <mesh position={[0, 1.1, 0]}>
         <sphereGeometry args={[0.25, 16, 16]} />
         <meshStandardMaterial color="white" />
       </mesh>
       {/* Ears */}
       <mesh position={[-0.1, 1.3, 0]}>
         <coneGeometry args={[0.08, 0.3, 4]} />
         <meshStandardMaterial color="orange" />
       </mesh>
       <mesh position={[0.1, 1.3, 0]}>
         <coneGeometry args={[0.08, 0.3, 4]} />
         <meshStandardMaterial color="orange" />
       </mesh>
    </group>
  );
};

const Fire = () => {
  const lightRef = useRef<THREE.PointLight>(null);
  const meshRef = useRef<THREE.Mesh>(null);

  useFrame((state) => {
    const t = state.clock.getElapsedTime();
    const flicker = 0.8 + Math.random() * 0.4;
    if(lightRef.current) {
        lightRef.current.intensity = 2 + Math.sin(t * 10) * 1 + flicker;
    }
    if(meshRef.current) {
        meshRef.current.scale.y = 1 + Math.sin(t * 15) * 0.3;
        meshRef.current.rotation.y += 0.1;
    }
  });

  return (
    <group position={[8, 0.5, 5]}>
      {/* Fire core */}
      <mesh ref={meshRef} position={[0, 0.5, 0]}>
        <coneGeometry args={[0.8, 1.5, 6]} />
        <meshBasicMaterial color="#FF4500" toneMapped={false} />
      </mesh>
      {/* Light */}
      <pointLight ref={lightRef} color="#FF6600" distance={15} decay={2} />
      {/* Logs */}
      <mesh rotation={[0, 0, 1.5]} position={[0, 0.2, 0]}>
        <cylinderGeometry args={[0.1, 0.1, 1.5]} />
        <meshStandardMaterial color="#3E2723" />
      </mesh>
       <mesh rotation={[0, 1.5, 1.5]} position={[0, 0.2, 0]}>
        <cylinderGeometry args={[0.1, 0.1, 1.5]} />
        <meshStandardMaterial color="#3E2723" />
      </mesh>
    </group>
  );
};

const DancingCats: React.FC = () => {
  return (
    <group>
      <Fire />
      {/* Cats circling the fire at [8, 0, 5] */}
      {Array.from({ length: 4 }).map((_, i) => {
        const angle = (i / 4) * Math.PI * 2;
        const radius = 3;
        const x = 8 + Math.cos(angle) * radius;
        const z = 5 + Math.sin(angle) * radius;
        return (
             <group key={i} rotation={[0, -angle + Math.PI/2, 0]} position={[x, 0, z]}>
                <Cat position={[0,0,0]} offset={i} />
             </group>
        );
      })}
    </group>
  );
};

export default DancingCats;
