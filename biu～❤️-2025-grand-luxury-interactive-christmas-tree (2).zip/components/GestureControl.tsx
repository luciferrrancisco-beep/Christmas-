import React, { useEffect, useRef, useState, useCallback } from 'react';
import { TreeState } from '../types';

interface GestureControlProps {
  onUpdate: (activityLevel: number) => void; // 0 to 1
}

const GestureControl: React.FC<GestureControlProps> = ({ onUpdate }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [streamActive, setStreamActive] = useState(false);
  const [manualOverride, setManualOverride] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Fallback mouse interaction
  const handleMouseMove = (e: React.MouseEvent) => {
    if (!streamActive || manualOverride) {
      // If mouse is near center, tree is formed. If moved rapidly or to edges, chaos increases.
      // Simply mapping Y position for "Unleash" effect for fallback
      const y = 1 - (e.clientY / window.innerHeight);
      // Only unleash if dragging or clicking? Let's just use a "Hold" button metaphor via UI
    }
  };
  
  const handleUnleashClick = () => {
    setManualOverride(true);
    // Pulse animation logic
    let val = 0;
    const interval = setInterval(() => {
        val += 0.1;
        onUpdate(Math.min(val, 1));
        if (val >= 1.5) {
            clearInterval(interval);
            // Return to normal
            const returnInterval = setInterval(() => {
                val -= 0.05;
                onUpdate(Math.max(val, 0));
                if (val <= 0) {
                    clearInterval(returnInterval);
                    setManualOverride(false);
                }
            }, 50);
        }
    }, 50);
  };

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { width: 320, height: 240 } });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
        setStreamActive(true);
      }
    } catch (err) {
      console.error("Camera access denied or failed", err);
      setError("Camera access needed for gesture control. Using manual mode.");
    }
  };

  // Simple Motion Detection Logic
  // Compares current frame with previous frame to detect "Movement Energy"
  useEffect(() => {
    if (!streamActive || !videoRef.current || !canvasRef.current) return;

    let previousFrameData: Uint8ClampedArray | null = null;
    let animationFrameId: number;
    const ctx = canvasRef.current.getContext('2d', { willReadFrequently: true });
    
    // Sensitivity configs
    const THRESHOLD = 20; 
    const DAMPING = 0.92;
    let currentEnergy = 0;

    const detectMotion = () => {
      if (!videoRef.current || !ctx || !canvasRef.current) return;
      
      const width = 50; // Low res for performance
      const height = 40;
      
      ctx.drawImage(videoRef.current, 0, 0, width, height);
      const imageData = ctx.getImageData(0, 0, width, height);
      const data = imageData.data;
      
      let motionPixels = 0;

      if (previousFrameData) {
        for (let i = 0; i < data.length; i += 4) {
          // Compare green channel (usually cleanest)
          const diff = Math.abs(data[i+1] - previousFrameData[i+1]);
          if (diff > THRESHOLD) {
            motionPixels++;
          }
        }
      }

      previousFrameData = data;
      
      // Calculate normalized energy (0 to 1)
      const motionRatio = motionPixels / (width * height);
      const targetEnergy = Math.min(motionRatio * 15, 1); // Amplify small movements
      
      // Smooth interpolation
      currentEnergy = currentEnergy * DAMPING + targetEnergy * (1 - DAMPING);
      
      if (!manualOverride) {
        // Threshold to switch modes or continuous value?
        // Prompt says: "Open hand unleash, Closed hand formed".
        // We use motion as proxy: Waving (Unleash/Chaos), Still (Formed).
        onUpdate(currentEnergy);
      }

      animationFrameId = requestAnimationFrame(detectMotion);
    };

    detectMotion();

    return () => cancelAnimationFrame(animationFrameId);
  }, [streamActive, onUpdate, manualOverride]);

  return (
    <div className="absolute bottom-4 left-4 z-50 flex flex-col items-start space-y-2 pointer-events-none">
       {/* Camera Feed Preview */}
       <div className="relative rounded-xl overflow-hidden border-2 border-yellow-500/50 shadow-[0_0_20px_rgba(255,215,0,0.3)] bg-black/80 backdrop-blur-sm pointer-events-auto">
          {!streamActive && !error && (
            <button 
                onClick={startCamera} 
                className="w-32 h-24 flex items-center justify-center text-xs text-yellow-500 font-bold tracking-widest hover:bg-white/10 transition-colors uppercase"
            >
              Enable Camera
            </button>
          )}
          {streamActive && (
             <video 
                ref={videoRef} 
                className="w-32 h-24 object-cover transform scale-x-[-1]" 
                muted 
                playsInline
             />
          )}
           {/* Invisible canvas for processing */}
          <canvas ref={canvasRef} width="50" height="40" className="hidden" />
          
          <div className="absolute bottom-1 left-0 w-full text-[10px] text-center text-yellow-500/80 font-mono">
            {streamActive ? "WAVE TO UNLEASH" : "CAM OFF"}
          </div>
       </div>

       {/* Manual Trigger for fallback */}
       <button 
         onMouseDown={handleUnleashClick}
         className="pointer-events-auto px-6 py-2 bg-gradient-to-r from-red-900 to-red-700 text-yellow-100 border border-yellow-500/50 rounded-full font-serif italic text-sm shadow-lg hover:scale-105 transition-transform active:scale-95"
       >
         Manual Unleash (Biu!)
       </button>
       
       <div className="text-white/50 text-[10px] max-w-[200px]">
          Gesture: Wave hand vigorously to explode tree. Stop to reform.
          <br/>
          Interaction: Move cursor to rotate view.
       </div>
    </div>
  );
};

export default GestureControl;
