import React, { useMemo, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { getTreeConePoint, getRandomSpherePoint, palette } from '../../utils/math';

const Foliage: React.FC<{ progress: number }> = ({ progress }) => {
  const count = 15000; // Dense foliage
  const meshRef = useRef<THREE.Points>(null);
  
  // Custom Shader
  const shaderMaterial = useMemo(() => {
    return new THREE.ShaderMaterial({
      uniforms: {
        uTime: { value: 0 },
        uProgress: { value: 0 }, // 0 = Formed, 1 = Chaos
        uColor1: { value: palette.emerald },
        uColor2: { value: palette.gold },
      },
      vertexShader: `
        uniform float uTime;
        uniform float uProgress;
        attribute vec3 aRandomPos;
        attribute vec3 aTargetPos;
        attribute float aSize;
        attribute float aSpeed;
        
        varying vec2 vUv;
        varying float vDarkness;

        // Easing function
        float cubicInOut(float t) {
          return t < 0.5
            ? 4.0 * t * t * t
            : 0.5 * pow(2.0 * t - 2.0, 3.0) + 1.0;
        }

        void main() {
          vUv = uv;
          
          float t = cubicInOut(uProgress);
          
          // Add some noise movement based on state
          vec3 noise = vec3(
            sin(uTime * aSpeed + aRandomPos.x),
            cos(uTime * aSpeed + aRandomPos.y),
            sin(uTime * aSpeed * 0.5 + aRandomPos.z)
          ) * (0.2 + 2.0 * uProgress); // Move more in chaos mode

          vec3 pos = mix(aTargetPos, aRandomPos + noise, t);
          
          vec4 mvPosition = modelViewMatrix * vec4(pos, 1.0);
          gl_Position = projectionMatrix * mvPosition;
          
          // Size attenuation
          gl_PointSize = aSize * (300.0 / -mvPosition.z);
          
          // Fade based on chaos distance
          vDarkness = smoothstep(0.0, 1.0, uProgress);
        }
      `,
      fragmentShader: `
        uniform vec3 uColor1;
        uniform vec3 uColor2;
        varying float vDarkness;

        void main() {
          // Circular particle
          vec2 coord = gl_PointCoord - vec2(0.5);
          if(length(coord) > 0.5) discard;
          
          // Mix colors based on position logic or randomness
          vec3 finalColor = mix(uColor1, uColor2, 0.1);
          
          // Make it glitter
          float glitter = step(0.95, fract(sin(dot(gl_FragCoord.xy, vec2(12.9898,78.233))) * 43758.5453));
          finalColor += vec3(glitter) * 0.5;

          gl_FragColor = vec4(finalColor, 1.0);
        }
      `,
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
    });
  }, []);

  const attributes = useMemo(() => {
    const randomPos = new Float32Array(count * 3);
    const targetPos = new Float32Array(count * 3);
    const sizes = new Float32Array(count);
    const speeds = new Float32Array(count);

    for (let i = 0; i < count; i++) {
      // Formed Tree Position
      const [tx, ty, tz] = getTreeConePoint(12, 4, 1); // Height 12, Radius 4, Offset 1
      targetPos[i * 3] = tx;
      targetPos[i * 3 + 1] = ty;
      targetPos[i * 3 + 2] = tz;

      // Chaos Sphere Position
      const [cx, cy, cz] = getRandomSpherePoint(15);
      randomPos[i * 3] = cx;
      randomPos[i * 3 + 1] = cy + 6; // Center sphere higher up
      randomPos[i * 3 + 2] = cz;

      sizes[i] = Math.random() * 0.5 + 0.1;
      speeds[i] = Math.random();
    }

    return { randomPos, targetPos, sizes, speeds };
  }, []);

  useFrame((state) => {
    if (meshRef.current) {
      const material = meshRef.current.material as THREE.ShaderMaterial;
      material.uniforms.uTime.value = state.clock.getElapsedTime();
      // Smooth interpolation for the uniforms
      material.uniforms.uProgress.value = THREE.MathUtils.lerp(
        material.uniforms.uProgress.value,
        progress,
        0.1
      );
    }
  });

  return (
    <points ref={meshRef} material={shaderMaterial}>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position" // Using target as initial position
          count={attributes.targetPos.length / 3}
          array={attributes.targetPos}
          itemSize={3}
        />
        <bufferAttribute
          attach="attributes-aTargetPos"
          count={attributes.targetPos.length / 3}
          array={attributes.targetPos}
          itemSize={3}
        />
        <bufferAttribute
          attach="attributes-aRandomPos"
          count={attributes.randomPos.length / 3}
          array={attributes.randomPos}
          itemSize={3}
        />
        <bufferAttribute
          attach="attributes-aSize"
          count={attributes.sizes.length}
          array={attributes.sizes}
          itemSize={1}
        />
        <bufferAttribute
          attach="attributes-aSpeed"
          count={attributes.speeds.length}
          array={attributes.speeds}
          itemSize={1}
        />
      </bufferGeometry>
    </points>
  );
};

export default Foliage;
