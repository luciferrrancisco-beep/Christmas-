import React, { useLayoutEffect, useRef, useMemo } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { getTreeConePoint, getRandomSpherePoint } from '../../utils/math';

interface OrnamentProps {
  progress: number;
}

const Ornaments: React.FC<OrnamentProps> = ({ progress }) => {
  // Types of ornaments
  const ORNAMENT_COUNT = 300;
  
  // Refs for InstancedMeshes
  const ballsRef = useRef<THREE.InstancedMesh>(null);
  const boxesRef = useRef<THREE.InstancedMesh>(null);
  const specialsRef = useRef<THREE.InstancedMesh>(null); // Cats, Tomatoes, IceCreams mixed
  
  // Dummy object for calculating matrices
  const dummy = useMemo(() => new THREE.Object3D(), []);

  // Data generation
  const data = useMemo(() => {
    return Array.from({ length: ORNAMENT_COUNT }).map((_, i) => {
      // Tree Position
      const [tx, ty, tz] = getTreeConePoint(11, 3.8, 1.5);
      // Chaos Position
      const [cx, cy, cz] = getRandomSpherePoint(18);
      
      const typeChance = Math.random();
      let type = 'ball';
      let scale = 0.3;
      let color = new THREE.Color().setHSL(Math.random(), 0.8, 0.5);

      if (typeChance > 0.9) {
        type = 'special'; // Tomato/Cat head etc
        scale = 0.5;
        color = new THREE.Color('#FF4500'); // Red-Orange
      } else if (typeChance > 0.6) {
        type = 'box'; // Gift
        scale = 0.4;
        color = new THREE.Color('#D4AF37'); // Gold
      } else {
        // High gloss ball
        if (Math.random() > 0.5) color = new THREE.Color('#C0C0C0'); // Silver
        else color = new THREE.Color('#FF0000'); // Red
      }

      // Physics weight (affects interpolation speed slightly)
      const weight = Math.random() * 0.05 + 0.05;

      // Rotation
      const rotation = [Math.random() * Math.PI, Math.random() * Math.PI, 0];

      return {
        target: new THREE.Vector3(tx, ty, tz),
        chaos: new THREE.Vector3(cx, cy + 6, cz),
        scale,
        color,
        type,
        weight,
        rotation: new THREE.Euler(...rotation),
        currentPos: new THREE.Vector3(tx, ty, tz), // State tracking
      };
    });
  }, []);

  useLayoutEffect(() => {
    // Initialize colors
    if (ballsRef.current && boxesRef.current && specialsRef.current) {
      let bIdx = 0, boxIdx = 0, sIdx = 0;
      data.forEach((d) => {
        if (d.type === 'ball') {
            ballsRef.current!.setColorAt(bIdx++, d.color);
        } else if (d.type === 'box') {
            boxesRef.current!.setColorAt(boxIdx++, d.color);
        } else {
            specialsRef.current!.setColorAt(sIdx++, d.color);
        }
      });
      ballsRef.current.instanceColor!.needsUpdate = true;
      boxesRef.current.instanceColor!.needsUpdate = true;
      specialsRef.current.instanceColor!.needsUpdate = true;
    }
  }, [data]);

  useFrame((state, delta) => {
    const t = state.clock.getElapsedTime();
    
    // Counters for the instances
    let bIdx = 0, boxIdx = 0, sIdx = 0;

    data.forEach((d) => {
      // Determine target vector based on progress
      // We want them to float around a bit in chaos mode
      const targetVec = progress > 0.5 ? d.chaos : d.target;
      
      // Add floating noise when in chaos
      const noise = progress > 0.5 ? Math.sin(t + d.chaos.x) * 0.5 : 0;
      const destination = targetVec.clone().add(new THREE.Vector3(0, noise, 0));

      // Lerp current position to destination
      // Using d.weight to make heavier items move slower
      const lerpFactor = THREE.MathUtils.clamp(delta * (2.0 + (1 - d.weight) * 2), 0, 1);
      
      d.currentPos.lerp(destination, lerpFactor);

      // Rotate objects
      dummy.position.copy(d.currentPos);
      dummy.rotation.copy(d.rotation);
      dummy.rotation.x += delta * 0.5 * progress; // Spin more in chaos
      dummy.rotation.y += delta * 0.5;
      dummy.scale.setScalar(d.scale * (1 + Math.sin(t * 5) * 0.1 * progress)); // Pulse in chaos

      dummy.updateMatrix();

      if (d.type === 'ball' && ballsRef.current) {
        ballsRef.current.setMatrixAt(bIdx++, dummy.matrix);
      } else if (d.type === 'box' && boxesRef.current) {
        boxesRef.current.setMatrixAt(boxIdx++, dummy.matrix);
      } else if (d.type === 'special' && specialsRef.current) {
        specialsRef.current.setMatrixAt(sIdx++, dummy.matrix);
      }
    });

    if (ballsRef.current) ballsRef.current.instanceMatrix.needsUpdate = true;
    if (boxesRef.current) boxesRef.current.instanceMatrix.needsUpdate = true;
    if (specialsRef.current) specialsRef.current.instanceMatrix.needsUpdate = true;
  });

  return (
    <group>
      {/* Glossy Balls */}
      <instancedMesh ref={ballsRef} args={[undefined, undefined, ORNAMENT_COUNT]}>
        <sphereGeometry args={[1, 32, 32]} />
        <meshStandardMaterial 
            roughness={0.1} 
            metalness={0.9} 
            envMapIntensity={2} 
        />
      </instancedMesh>

      {/* Gift Boxes */}
      <instancedMesh ref={boxesRef} args={[undefined, undefined, ORNAMENT_COUNT]}>
        <boxGeometry args={[1, 1, 1]} />
        <meshStandardMaterial 
            roughness={0.3} 
            metalness={0.6} 
            envMapIntensity={1.5}
        />
      </instancedMesh>

       {/* Special Items (Tomatoes/IceCreams represented by Dodecahedrons for sparkle) */}
       <instancedMesh ref={specialsRef} args={[undefined, undefined, ORNAMENT_COUNT]}>
        <dodecahedronGeometry args={[1, 0]} />
        <meshStandardMaterial 
            roughness={0.2} 
            metalness={0.5} 
            emissive="#330000"
            emissiveIntensity={0.5}
        />
      </instancedMesh>
    </group>
  );
};

export default Ornaments;
